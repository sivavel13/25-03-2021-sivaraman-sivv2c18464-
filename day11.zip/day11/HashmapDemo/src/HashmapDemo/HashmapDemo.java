package HashmapDemo;

import java.util.HashMap;
import java.util.*;

public class HashmapDemo {

	public static void main(String[] args) {
		
		HashMap<String, Integer> Marks = new  HashMap();
		
		Marks.put("Tamil", 91);
		Marks.put("English", 81);
		Marks.put("Mathas", 95);
		Marks.put("Physics", 71);
		Marks.put("Chemistry", 93);
		Marks.put("Environment", null);  //null value allow
		
		for (Map.Entry<String, Integer> i : Marks.entrySet()) {
			System.out.println("Key : " + i.getKey() + ", Value : " + i.getValue() );
		}
		
		System.out.println("Value: " + Marks.get("Tamil"));  //get the key value
		System.out.println("Size of the Marks collections : " + Marks.size());  //size
		System.out.println(Marks.containsKey("Tamil")); //contain or not 
		System.out.println(Marks.containsValue(90));    //like true or false
		System.out.println(Marks.remove("Environment"));  //remove specific items
		System.out.println(Marks);
		Marks.clear();
		System.out.println(Marks); //clear all elements

	}

}
